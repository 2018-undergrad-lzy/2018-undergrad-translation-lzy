/*
 * Copyright (C) 2011-2018 Intel Corporation. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 *   * Redistributions of source code must retain the above copyright
 *     notice, this list of conditions and the following disclaimer.
 *   * Redistributions in binary form must reproduce the above copyright
 *     notice, this list of conditions and the following disclaimer in
 *     the documentation and/or other materials provided with the
 *     distribution.
 *   * Neither the name of Intel Corporation nor the names of its
 *     contributors may be used to endorse or promote products derived
 *     from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 * OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 */


#include <stdarg.h>
#include <cstdio>      /* vsnprintf */

#include "Enclave.h"
#include "Enclave_t.h"  /* print_string */
//包括edl的同名的_t.h文件

#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<openssl/rsa.h>
#include<openssl/pem.h>
#include<openssl/err.h>

#include <errno.h>
#include <sys/types.h>
#include <sys/ioctl.h>
#include <unistd.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <linux/netdevice.h>
#include <linux/sockios.h>
#include <linux/if.h>
#include <asm/types.h>
#include <linux/netlink.h>
#include <linux/rtnetlink.h>
#include <net/if_arp.h>
#include <netinet/if_ether.h>
#include <netinet/ether.h>

#include <fcntl.h>
#include <sys/socket.h>

#define OPENSSLKEY "test.key"
#define PUBLICKEY "test_pub.key"
#define BUFFSIZE 1024
#define SIZE 1024

#define LIC_FILE  "lic.rn"
#define LIC_FILE2  "lic2.rn"
#define PRTFL printf("fun = %s, line = %d\n", __FUNCTION__,__LINE__)

static char *ptr_en;
static char *p_en;
static RSA  *p_rsa_public;
static FILE  *fp_public;
static int flen_public, rsa_public_len;


static char *ptr_de;
static char *p_de;
static RSA  *p_rsa_private;
static FILE  *fp_private;
static int flen_private, rsa_private_len;


#include "sgx_trts.h"                 //包括可信的头文件
#include <string.h>
void dck_test(char *buf,size_t len)   //拷贝函数
{
    const char *secret="Hello Enclave!";
    if(len>=0)
    {
        memcpy(buf,secret,strlen(secret)+1);
    }
}


void reencryption(FILE *pf_tmp,FILE *pf_tmp2)   //拷贝函数
{
    int i, ret , len;
    unsigned char buf_plain[32];
    unsigned char *buf_en;
    unsigned char *raw_buffer;



    fp_private=fopen(OPENSSLKEY,"r");


    p_rsa_private=PEM_read_RSAPrivateKey(fp_private,NULL,NULL,NULL);


    rsa_private_len = RSA_size(p_rsa_private);


    raw_buffer = calloc(rsa_private_len,sizeof(char));

    fread(raw_buffer,  sizeof(char),128, pf_tmp);

    p_de=(unsigned char *)malloc(rsa_private_len+1);
    memset(p_de,0,rsa_private_len+1);

    //printf("%s(%d)p_en = %p,rsa_public_len = %d\n", __FUNCTION__,__LINE__,p_en,rsa_public_len);
    len =RSA_private_decrypt (rsa_private_len,raw_buffer,p_de,p_rsa_private,RSA_NO_PADDING);
    printf("%s(%d)Enclave decrypt :p_de = %s\n",__FUNCTION__,__LINE__,p_de);





    fp_public=fopen(PUBLICKEY,"r"));

    p_rsa_public = PEM_read_RSA_PUBKEY(fp_public,NULL,NULL,NULL);


    rsa_public_len=RSA_size(p_rsa_public);
    p_en=(unsigned char *)malloc(rsa_public_len+1);
    memset(p_en,0,rsa_public_len+1);
    //printf("%s(%d)p_en = %p,rsa_public_len = %d\n", __FUNCTION__,__LINE__,p_en,rsa_public_len);

    len = RSA_public_encrypt(rsa_public_len,buf_plain,p_en,p_rsa_public,RSA_NO_PADDING);


    printf("new_ciphertext:%s\n",p_en);


    pf_tmp2 = fopen(LIC_FILE2,"w");

    fwrite(p_en,1,128,pf_tmp2);
    fclose(pf_tmp2);



}



/* 
 * printf: 
 *   Invokes OCALL to display the enclave buffer to the terminal.
 */
void printf(const char *fmt, ...)
{
    char buf[BUFSIZ] = {'\0'};
    va_list ap;
    va_start(ap, fmt);
    vsnprintf(buf, BUFSIZ, fmt, ap);
    va_end(ap);
    ocall_print_string(buf);
}
